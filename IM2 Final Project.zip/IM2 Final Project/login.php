 <?php
include 'views/header.php';
?>

<form id="loginform" action="" method="POST">
    <label for="uname">Username or Email</label>
    <input type="text" name="uname" id="uname" placeholder="user or email" required>
    
    <label for="pass">Password</label>
    <input type="password" name="pass" id="pass" required>
    
    <div>
        <input type="checkbox" name="keep_signed_in" id="keep_signed_in">
        <label for="keep_signed_in">Keep me signed in</label>
    </div>
    
    <input type="submit" value="Login">
</form>  

<?php
include 'views/footer.php';
?>