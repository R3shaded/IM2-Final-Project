<?php
include 'views/header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home | Social Media</title>
    <link rel="stylesheet" href="res/style.css">
</head>
<body>
    <div class="container">
        <h2 style="text-align:center; color:#1C3D58;">GameCord</h2> 

        <hr>

        <div id="postform">
            <h3>Share a new post</h3>
            <form action="submit_post.php" method="POST">
                <textarea name="post_content" placeholder="What's on your mind?" rows="4" required></textarea>
                <input type="submit" value="Post">
            </form>
        </div>

        <hr>

        <h3 style="text-align:center; color:#1C3D58;">Recent Posts</h3>

        <div class="feed">
            <div class="post">
                <strong>@john_doe</strong>
                <small>Posted on: 2025-04-21 at 14:30</small>
                <p> I LOVE CATS</p>
                <img src="res/cats.jpg" alt="Post Image">
            </div>

            <div class="post">
                <strong>@jane_doe</strong>
                <small>Posted on: 2025-04-20 at 19:15</small>
                <p>I LOVE DOGS!</p>
                <img src="res/dog.jpg" alt="Post Image">
            </div>

            <div class="post">
                <strong>@mike_smith</strong>
                <small>Posted on: 2025-04-19 at 12:05</small>
                <p>I LOVE FISHES</p>
                <img src="res/fish.jpg" alt="Post Image">
            </div>
        </div>
    </div>

<?php include 'views/footer.php'; ?>
</body>
</html>