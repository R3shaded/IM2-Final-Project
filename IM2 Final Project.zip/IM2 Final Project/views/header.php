<!DOCTYPE html>

<html>
      <head>
         <meta charset="UTF-8">
         <title>socmed</title>
         <link href="./res/style.css" rel="stylesheet" type="text/css"/>
      </head>
    <body>
        <div class="navbar">
            <a href="./index.php">Home</a>
            <a href="./userprofile.php">Profile</a>
            <?php
            if(isset($_SESSION['uid'])){
            ?>
            <a href="./profile.php"><?php echo $_SESSIONP['username'];?></a>
            <a href=".models/logout.php">Logout</a>
            <?php
            }
            else{
            ?>
               <a href="./login.php">Login</a>
               <a href="./register.php">Registration</a>
            <?php
            }
            ?> 
        </div>