<?php
include 'views/header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile | Social Media</title>
    <link rel="stylesheet" href="res/style.css"> <!-- Link to external CSS -->
</head>
<body>
    <div class="container">
        <div id="profile-header" style="text-align:center; padding: 2em;">
            <img src="res/pfp.jpg" alt="Profile Picture" style="border-radius: 50%; width: 150px; height: 150px;">
            <h2 style="color:#1C3D58;">@Mugetsu</h2> <!-- User's name, replace with PHP variable -->
            <p style="color:#1C3D58;">Professional Codm Player ign:Mugetsu.</p>
        </div>

        <hr>

        <!-- User's Recent Posts -->
        <h3 style="text-align:center; color:#1C3D58;">Recent Posts</h3>

        <div class="feed">
            <div class="post">
                <strong>@Mugetsu</strong>
                <small>Posted on: 2025-04-21 at 14:30</small>
                <p>YOOOOO</p>
                <img src="res/win1.png" alt="Post Image">
            </div>

            <div class="post">
                <strong>@Mugetsu</strong>
                <small>Posted on: 2025-04-20 at 19:15</small>
                <p>CLUTCH BRO.</p>
                <img src="res/win2.png" alt="Post Image">
            </div>

            <div class="post">
                <strong>@Mugetsu</strong>
                <small>Posted on: 2025-04-19 at 12:05</small>
                <p>CLUTCH.</p>
                <img src="res/win3.png" alt="Post Image">
            </div>
        </div>

        <hr>

        
        <div style="text-align:center;">
            <a href="edit_profile.php" style="text-decoration:none; background-color:#1C3D58; color:white; padding: 1em 2em; border-radius: 10px;">Edit Profile</a>
        </div>
    </div>

<?php include 'views/footer.php'; ?>
</body>
</html>