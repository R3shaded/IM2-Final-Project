<?php
include 'views/header.php';
?>  
<div></div>
<form id="loginform" action="Models/register_user.php
      " method="POST">
    <div class="header">REGISTER</div>
    <?php
    if(isset($_GET['uname_error']) && $_GET['uname_error'] == 1){
        if($_GET['uname_error']==1){
            echo "div class='error_message'>Invalid username</div";
        }
    }
    ?>
    <label for="uname">Username:</label>
    <input type="text" name="uname" id="uname" placeholder="Username" required>
    <?php
    if(isset($_GET['email_error']) && $_GET['email_error'] == 1){
        if($_GET['email_error']==1){
            echo "div class='error_message'>Invalid email</div";
        }
    }
    ?>
    <label for="email">Email:</label>
    <input type="text" name="email" id="email" placeholder="Email" required>
    <label for="fname">First name:</label>
    <input type="text" name="fname" id="fname" placeholder="First name" required>
    <label for="lname">Last name:</label>
    <input type="text" name="lname" id="lname" placeholder="Last name" required>
    <div id="cbgender">
        <label for="gender">Gender</label>
        <select id="gender" name="gender">
            <option value="male">Male</option>
            <option value="female">Female</option>
        </select>
    </div>
    <label for="bdate">Birthday</label>
    <input type="date" name="bdate" id="bdate" required>
    <label for="password">Password:</label>
    <input type="password" name="pass" id="pass" placeholder="Password" required>
    <label for="conpass">Confirm Password:</label>
    <input type="password" name="conpass" id="conpass" placeholder="Confirm Password" required>    
        <div id="signedin">
            
        </div>
    <input type="submit" value="register">
</form>

<?php
include 'views/footer.php';
?>