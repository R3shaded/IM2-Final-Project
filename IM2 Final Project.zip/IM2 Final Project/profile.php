<?php
include 'views/header.php';

if (isset($_SESSION['firstname']) && isset($_SESSION['lastname'])) {
    echo "Firstname: " . htmlspecialchars($_SESSION['firstname']) . "<br>";
    echo "Lastname: " . htmlspecialchars($_SESSION['lastname']) . "<br>";
} else {
    echo "User details not available.";
}

include 'views/footer.php';

?>