<?php

function create_connection(){
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "socmed_climaco_d";

    return new mysqli($host,$username,$password,$database);

}