<?php

require "dbconnection.php";

$un = htmlspecialchars($_POST['uname']);
$em = htmlspecialchars($_POST['email']);
$fn = htmlspecialchars($_POST['fname']);
$ln = htmlspecialchars($_POST['lname']);
$gndr = htmlspecialchars($_POST['gender']); // Fixed case sensitivity
$bdate = htmlspecialchars($_POST['bdate']);
$pass = htmlspecialchars($_POST['pass']);
$conpass = htmlspecialchars($_POST['cpass']);

$con = create_connection();

if ($con->connect_error) {
    die("Connection Failed");
}

// Check username availability
$uname_error = 0;
$sql_uname = "SELECT * FROM user WHERE username='$un'";
$result_uname = $con->query($sql_uname);
if ($result_uname->num_rows > 0) {
    $uname_error = 1;
}

// Check email availability
$email_error = 0;
$sql_email = "SELECT * FROM user WHERE email='$em'";
$result_email = $con->query($sql_email);
if ($result_email->num_rows > 0) {
    $email_error = 1;
}

// Check password confirmation
$pass_match = strcmp($pass, $conpass);

// Registration logic
if ($pass_match === 0 && $uname_error == 0 && $email_error == 0) {
    $hashed_pass = password_hash($pass, PASSWORD_DEFAULT); // Secure password hashing
    $sql_insert = "INSERT INTO user VALUES (0, '$un', '$fn', '$ln', '$em', '$gndr', '$bdate', '$hashed_pass')";
    
    if ($con->query($sql_insert) === TRUE) {
        header("Location: ../login.php?regsuccess=1");
        exit;
    } else {
        die("Error: " . $con->error);
    }
} else {
    header("Location: ../register.php?uname_error=" . $uname_error . "&email_error=" . $email_error);
    exit;
}
?>
